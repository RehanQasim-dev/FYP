#include "static.h"

int b(void) {
	return 'b';
}
