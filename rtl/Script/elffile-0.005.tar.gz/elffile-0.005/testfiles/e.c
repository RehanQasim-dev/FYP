#include "dynamic.h"

int e(void) {
	return 'e';
}
