#include "static.h"

char a(void) {
	return 'a';
}
