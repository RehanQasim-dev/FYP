char d(void);
int e(void);
long f(void);
