#include "dynamic.h"

long f(void) {
	return 'f';
}
