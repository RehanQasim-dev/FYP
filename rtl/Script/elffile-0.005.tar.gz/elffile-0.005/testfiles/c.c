#include "static.h"

long c(void) {
	return 'c';
}
