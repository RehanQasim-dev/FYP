#include "dynamic.h"

char d(void) {
	return 'd';
}
