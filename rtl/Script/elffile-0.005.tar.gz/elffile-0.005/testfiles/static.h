char a(void);
int b(void);
long c(void);
